from geopy.geocoders import Nominatim

def get_lat_long_from_place(place_name):
    geolocator = Nominatim(user_agent="geoapiEx")
    location = geolocator.geocode(place_name)
    if location:
        return location.latitude, location.longitude
    else:
        return None, None

if __name__ == "__main__":
    place_name = "Greater Kailash, Delhi"

    latitude, longitude = get_lat_long_from_place(place_name)
    if latitude is not None and longitude is not None:
        print(f'The latitude and longitude for {place_name} are: {latitude}, {longitude}')
    else:
        print(f'No coordinates found for {place_name}')
