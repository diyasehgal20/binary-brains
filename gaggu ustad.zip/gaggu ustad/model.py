import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
import folium


data = {
    'latitude': [28.6780,28.5878,28.6643,28.7204,28.6868,28.5290,28.5370,28.6516,28.6396],
    'longitude': [77.2910,77.2471,77.0670,77.0619,77.2772,77.1544,77.2495,77.1433,77.0947],
    'threat_level': [ 'high','high','medium','medium','medium','low','low', 'low', 'low'],
    'place_name': ['sultanpuri', 'shahdara', 'nihal vihar', 'babarpur','begumpur','vasant kunj','greater kailash','kirti nagar','tilak nagar'] 
}

df = pd.DataFrame(data)


threat_level_mapping = {'low': 0, 'medium': 1, 'high': 2}
df['threat_level_numeric'] = df['threat_level'].map(threat_level_mapping)

# Features and labels
X = df[['latitude', 'longitude']]
y = df['threat_level_numeric']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a simple decision tree classifier
clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)

# Create a Folium map
m = folium.Map(location=[np.mean(df['latitude']), np.mean(df['longitude'])], zoom_start=6)

# Function to assign colors based on threat level
def assign_color(threat_level):
    if threat_level == 2:
        return 'red'
    elif threat_level == 1:
        return 'orange'
    else:
        return 'green'

# Add markers to the map with colors based on threat level
for i, row in df.iterrows():
    folium.CircleMarker(
        location=[row['latitude'], row['longitude']],
        radius=10,
        color=assign_color(row['threat_level_numeric']),
        fill=True,
        fill_color=assign_color(row['threat_level_numeric']),
        fill_opacity=0.7
    ).add_to(m)

# Save the map to an HTML file
m.save('threat_level_map.html')
